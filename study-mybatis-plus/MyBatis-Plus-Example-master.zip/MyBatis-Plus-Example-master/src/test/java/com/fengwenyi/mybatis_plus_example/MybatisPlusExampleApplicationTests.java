package com.fengwenyi.mybatis_plus_example;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MybatisPlusExampleApplicationTests {

    @Test
    public void contextLoads() {
    }

}
